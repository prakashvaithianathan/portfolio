import Mockup from './Mockup/Mockup'
import Javascript from './Javascript/Javascript'
import Laptop from './Laptop/Laptop'
import AwsBlog from './AwsBlog/AwsBlog'
import Bootstrap from './Bootstrap/Bootstrap'

export {Mockup,Javascript,Laptop,AwsBlog,Bootstrap}